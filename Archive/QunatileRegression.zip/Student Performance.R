install.packages("naniar")
install.packages("tidyverse")
install.packages("readxl")
install.packages("quantreg")
install.packages("ggplot2")

library(tidyverse)
library(naniar)
library(readxl)
library(quantreg)
library(ggplot2)


                                  ### Student Study Data (Manually Imported Data) ###

## https://data.library.virginia.edu/getting-started-with-quantile-regression/

# All Models (0.25, 0.5, 0.75, and 0.9)

qr0.25 <- rq(Scores ~ Hours, data=Student_Study_Hour_V2, tau = 0.25)
summary(qr0.25)                         
ggplot(Student_Study_Hour_V2, aes(Hours,Scores)) + geom_point() + 
  geom_abline(intercept=coef(qr0.25)[1], slope=coef(qr0.25)[2])

qr0.5 <- rq(Scores ~ Hours, data=Student_Study_Hour_V2, tau = 0.5)
summary(qr0.5)                         
ggplot(Student_Study_Hour_V2, aes(Hours,Scores)) + geom_point() + 
  geom_abline(intercept=coef(qr0.5)[1], slope=coef(qr0.5)[2])


qr0.75 <- rq(Scores ~ Hours, data=Student_Study_Hour_V2, tau = 0.75)
summary(qr0.75)                         
ggplot(Student_Study_Hour_V2, aes(Hours,Scores)) + geom_point() + 
  geom_abline(intercept=coef(qr0.75)[1], slope=coef(qr0.75)[2])

qr0.9 <- rq(Scores ~ Hours, data=Student_Study_Hour_V2, tau = 0.9)
summary(qr0.9)                         
ggplot(Student_Study_Hour_V2, aes(Hours,Scores)) + geom_point() + 
  geom_abline(intercept=coef(qr0.9)[1], slope=coef(qr0.9)[2])

# Model ranging from 0.1 to 0.9 percentile with graph

qs <- 1:9/10
qr2 <- rq(Scores ~ Hours, data=Student_Study_Hour_V2, tau = qs)
coef(qr2)
ggplot(Student_Study_Hour_V2, aes(Hours,Scores)) + geom_point() + geom_quantile(quantiles = qs)

plot(summary(qr2), parm="Hours")

# Test the difference in 0.25 and 0.5
anova(qr0.25, qr0.5)
# Test the difference in 0.25 and 0.75
anova(qr0.25, qr0.75)
# Test the difference in 0.25 and 0.9
anova(qr0.25, qr0.5, qr0.75, qr0.9)

#Final Summary from 0.1 to 0.9 percentile with graph

QR=rq(Scores~Hours,data=Student_Study_Hour_V2, tau=seq(0.1, 0.9, by=0.1))
summary(QR)
sumQR=summary(QR)
plot(sumQR)

ggplot(Student_Study_Hour_V2) + geom_jitter(aes(Hours,Scores)) + geom_point() + 
  geom_abline(intercept=coef(qr0.25)[1], slope=coef(qr0.25)[2])

#Plot with all taus on it 

FullModel <- rq(Scores ~ Hours, data=Student_Study_Hour_V2, tau=c(0.25, 0.5, 0.75,0.9))
summary(FullModel)
quantile.regressions <- data.frame(t(coef(FullModel)))
colnames(quantile.regressions) <- c("intercept", "slope")
quantile.regressions$quantile <- rownames(quantile.regressions)
quantile.regressions


scatterplot <- qplot(x=Hours, y=Scores, data=Student_Study_Hour_V2)
scatterplot + geom_abline(aes(intercept=intercept, slope=slope,
                              colour=quantile), data=quantile.regressions)


#Linear Model 
LM <- lm(Scores~Hours, data=Student_Study_Hour_V2)
summary(LM)
scatterplot + geom_abline(aes(intercept=3.2017, slope=9.6774)) 
ggplot(data = Student_Study_Hour_V2, aes(x=Hours)) + 
  geom_histogram( binwidth=5, color="white", fill="lightblue") + ggtitle("Histogram of The Amount Crawling Based on Temperature")

#Breusch-Pagan test
lmtest::bptest(LM)

res <- resid(LM)
plot(fitted(LM), res)
abline(0,0)